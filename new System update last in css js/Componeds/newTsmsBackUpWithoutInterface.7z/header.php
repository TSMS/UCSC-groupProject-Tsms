<ul id="nav">
	
	<table>
	<tr>
		<td><li><a href="index1.php">Home</a></li></td>
		<td><li><a href="add_suppliers.php">Add Customer</a></li></td>
		<td><li><a href="update.php">User Update</a></li></td>
		<td><li><a href="search.php">User Search</a></li></td>
		<td><li><a href="usersettings.php">User Settings</a></li></td>
		<td><li><a href="changePassword.php">Change Password</a></li></td>
		<td><li><a href="logout.php">Log Out</a></li></td>
	</tr>
</table>
	
</ul>
<div id="content"></div>
<script src="js/jquery-1.11.3.min.js"></script>

<style>
table {
    border-spacing: 5px;
}

th {
    text-align: left;
} 

table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 15px;
}

</style>