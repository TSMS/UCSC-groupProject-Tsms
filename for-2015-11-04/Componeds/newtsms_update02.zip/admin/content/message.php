<h1>Lili Message</h1>

<?php

if( isset( $_POST['submit_form'] ) )
{

echo "hutaaa";

}
?>



<form method="POST" action="">
	 	<input type="text" name="username" id="name_of_user">
	 	<input type="text" name="userage" id="age_of_user">
	 	<input type="text" name="usercourse" id="course_of_user">
	 	<input type="submit" name="submit_form" value="Submit">
 </form>
