    <!-- Local ajex file -->
    <script src="dist/jquery-1.11.3.min.js"></script>
    <script src="dist/general.js"></script>
    <!-- jQuery 2.1.4 -->
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>

    <!-- Optionally, you can add Slimscroll and FastClick plugins.
         Both of these plugins are recommended to enhance the
         user experience. Slimscroll is required when using the
         fixed layout. -->
  </body>
</html>