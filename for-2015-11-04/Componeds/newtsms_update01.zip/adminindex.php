<h1>Heloow</h1>
<a href="logout.php">logout</a>