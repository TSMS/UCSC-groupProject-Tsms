<footer class="main-footer">
	<!-- To the right -->
	<div class="pull-right hidden-xs">
	  2012/13 UCSC - this is for 2nd year group project
	</div>
	<!-- Default to the left -->
	<strong>Copyright &copy; 2015 <a href="#">tsms -Group -5</a>.</strong> All rights reserved.
</footer>