<?php

require_once 'core/init.php';
if(Session::exists('success')){
    echo Session::flash('success');
}

$user = new User();

if($user->isLoggedIn()){
?>
<div class="page page-dashboard" data-ng-controller="DashboardCtrl">
<div class="page">
	<div class="row">
		<div class="col-md-6">
            <!-- Collapse -->
            <section class="panel panel-default">
                <div class="panel-body" data-ng-controller="CollapseDemoCtrl">
</div>
    <p>Hello, <a href="profile.php?user=<?php echo escape($user->data()->username);?>"><?php echo escape($user->data()->username);?></a></p>

    <ul>
        <li><a href="logout.php">Log Out</a></li>
        <li><a href="changePassword.php">Change Password</a></li>
        <li><a href="../add_suppliers.php">Add Supplier</a></li>
    </ul>
    </div>
</section>
</div>
</div>
</div>
<?php
    if(Input::exists()){
        $user->update(array(
                        'name'  => Input::get('name')
                    ));
                    Session::flash('success', 'Information Updated Successfully');
                    Redirect::to('index.php');
    }
?>
<div class="page">
	<div class="row">
		<div class="col-md-6">
            <!-- Collapse -->
            <section class="panel panel-default">
                <div class="panel-body" data-ng-controller="CollapseDemoCtrl">
    <p><a href="search.php">Search users</a></p><br>
    <p><a href="daily_update.php">Daily Update</a></p></br>
<?php
    if($user->apprved_user('approved')){
        echo 'hii approved user</br>';
    }

    if($user->hasPermission('admin')){
        echo '<p>You are an administratior.</p> </br> 
              <li><a href="update.php">Update Detail</a></li>'
?>				
				</div>
			</section>
		</div>
	</div>
</div>
<div class="page">
	<div class="row">
		<div class="col-md-6">
            <!-- Collapse -->
            <section class="panel panel-default">
                <div class="panel-body" data-ng-controller="CollapseDemoCtrl">
                    <button class="btn btn-success" ng-click="isCollapsed = !isCollapsed">User Settings</button>
                    <hr>
                    <div collapse="isCollapsed">
                        <p> here it is</p>

            <table>
                <tr>
                    <td width='150px'>Users</td>
                    <td>Options</td>
                 </tr>
<?php 
            $list = DB::getInstance()->query("SELECT id, username, user_approved FROM users");
            if(!$list->count()){
                echo 'There is no user to Activate or diactivate';
            }else{
                foreach ($list->results() as $name){
                    $u_id = $name->id;
                    $u_type = $name->user_approved;
    ?>
                    <tr><td><?php echo $name->username ?></td><td>   
                    <?php
                    if($u_type == '1'){        
                        echo "<a href='../activated_or_die.php?u_id=$u_id&type=$u_type'>Deactivate</a>";
                    }else{
                        echo "<a href='../activated_or_die.php?u_id=$u_id&type=$u_type'>Activate</a>";
                    }
                }
            }

?>
        </table>
    				</div>            
                </div>
            </section>
            <!-- end Collapse -->
        </div>
    </div>
</div>
<?php
           
        }else{
            echo 'standard user';
        }
    }
?>

</div>
 