<?php
require_once 'core/init.php';
if(Session::exists('success')){
    echo Session::flash('success');
}

$user = new User();

?>

<div class="page page-lock">

    <div class="lock-centered clearfix">
        <div class="lock-container">
            <!-- <div ui-time class="lock-time"></div> -->
            
            <section class="lock-box">
                <div class="lock-user"><?php echo escape($user->data()->username);?></div>
                <div class="lock-img"><img src="<?php echo escape($user->data()->image);?>" alt=""></div>
                <div class="lock-pwd">
                    <form>
                        <div class="form-group">
                            <input type="password" placeholder="Password" class="form-control">
                            <a href="#/" class="btn-submit">
                                <i class="fa fa-arrow-right"></i>
                            </a>
                        </div>
                    </form>
                </div>            
            </section>
        </div>
    </div>
</div>