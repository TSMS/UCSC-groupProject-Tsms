<html>
<meta charset="UTF-8">
      <title>TSMS login page</title>
      <link rel="stylesheet" href="style/css/reset.css">
      <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
      <link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
      <link rel="stylesheet" href="style/css/style.css">
      <link rel="stylesheet" href="styles/main.css">
      <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body>


<form id="form" class="form-horizontal" role="form">
<div class="from-group">
	<label class="control-label col-sm-2" for="date">Date</label>
	<input type="date" id="date" clss="form-control">
</div>	
</form>





<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="bootstrap/js/jquery-1.11.3.min.js"></script>
 </body>
 </head>
 </html>