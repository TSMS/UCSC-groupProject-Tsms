
<div class="page page-profile">

    <div class="row">
        <div class="col-md-6">

            <div class="panel panel-profile">
                <div class="panel-heading bg-primary clearfix">
                    <a href="" class="pull-left profile">
                        <img alt="" src="images/g1.jpg" class="img-circle img80_80">
                    </a>
                    <h3>Thusitha thiyushan</h3>
                    <p>Project Manager</p>
                </div>
                <ul class="list-group">
                    <li class="list-group-item">
                        <span class="badge badge-danger">6</span>
                        <i class="fa fa-envelope-o"></i>
                        Inbox Messages
                    </li>
                    <li class="list-group-item">
                        <span class="badge badge-warning">2</span>
                        <i class="fa fa-comments-o"></i>
                        Dapibus ac facilisis in
                    </li>
                    <li class="list-group-item">
                        <span class="badge badge-info">1</span>
                        <i class="fa fa-heart-o"></i>
                        Morbi leo risus
                    </li>
                    <li class="list-group-item">
                        <span class="badge badge-success">3</span>
                        <i class="fa fa-folder-open-o"></i>
                        Vestibulum at eros
                    </li>
                </ul>
            </div>
          
        </div>
        <div class="col-md-6">

            <div class="panel panel-default">
                <div class="panel-heading"><strong><span class="glyphicon glyphicon-th"></span> Profile Info</strong></div>
                <div class="panel-body">
                    <div class="media">
                        <div class="media-body">
                            <ul class="list-unstyled list-info">
                                <li>
                                    <span class="icon glyphicon glyphicon-user"></span>
                                    <label>User name</label>
                                    {{main.name}}
                                </li>
                                <li>
                                    <span class="icon glyphicon glyphicon-envelope"></span>
                                    <label>Email</label>
                                    thusitha.4t@gmail.com
                                </li>
                                <li>
                                    <span class="icon glyphicon glyphicon-home"></span>
                                    <label>Address</label>
                                    No 60, River side, Gampola
                                </li>
                                <li>
                                    <span class="icon glyphicon glyphicon-earphone"></span>
                                    <label>Contact</label>
                                    (+075) 584 4848
                                </li>
                                <li>
                                    <span class="icon glyphicon glyphicon-flag"></span>
                                    <label>Nationality</label>
                                    Srilanaka
                                </li>
                            </ul>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="panel panel-default">
        <div class="panel-heading"><strong><span class="glyphicon glyphicon-th"></span> Table - General</strong></div>
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Project</th>
                    <th>Manager</th>
                    <th>Status</th>
                    <th>Progress</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td><span class="color-success"><i class="fa fa-level-up"></i></span> TWLT</td>
                    <td>Amery Lee</td>
                    <td><span class="label label-info">Pending</span></td>
                    <td><progressbar class="progressbar-xs no-margin" value="55"></progressbar>
                </tr>
                <tr>
                    <td>2</td>
                    <td><span class="color-success"><i class="fa fa-level-up"></i></span> A16Z</td>
                    <td>Romayne Carlyn</td>
                    <td><span class="label label-primary">Due</span></td>
                    <td><progressbar class="progressbar-xs no-margin" value="34" type="success"></progressbar></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td><span class="color-warning"><i class="fa fa-level-down"></i></span> DARK</td>
                    <td>Marybeth Joanna</td>
                    <td><span class="label label-success">Due</span></td>
                    <td><progressbar class="progressbar-xs no-margin" value="68" type="info"></progressbar></td>
                </tr>
                <tr>
                    <td>4</td>
                    <td><span class="color-info"><i class="fa fa-level-up"></i></span> Q300</td>
                    <td>Jonah Benny</td>
                    <td><span class="label label-danger">Blocked</span></td>
                    <td><progressbar class="progressbar-xs no-margin" value="52" type="warning"></progressbar></td>
                </tr>
                <tr>
                    <td>5</td>
                    <td><span class="color-danger"><i class="fa fa-level-down"></i></span> RVNG</td>
                    <td>Daly Royle</td>
                    <td><span class="label label-warning">Suspended</span></td>
                    <td><progressbar class="progressbar-xs no-margin" value="77" type="danger"></progressbar></td></td>
                </tr>

            </tbody>
        </table>
    </div>


</div>