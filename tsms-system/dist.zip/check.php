<?php 

// $msg=$_POST['fname'];
// //$msg=$_POST['text-msg'];

// echo $msg;

?>


<html>
<head>
	<title></title>
	 <?php include "include/head.php" ?>
	<script type="text/javascript" src="plugins/alert/dist/jquery-1.11.3.min.js"></script>
	<script type="text/javascript" src="plugins/alert/dist/sweetalert.min.js"></script>
	<script type="text/javascript" src="plugins/alert/dist/sweetalert-dev.js"></script>
	<script type="text/javascript" src="plugins/alert/dist/alert.js"></script>
</head>
<body>

</body>
</html>